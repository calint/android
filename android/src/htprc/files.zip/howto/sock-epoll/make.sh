gcc -o ctp ctp.c -Wfatal-errors -Wall -Wextra&&
ls -l ctp
