o=qmenu
gcc -o $o *.c -lX11 -Wfatal-errors -Wall -Wextra&&
ls -l $o
