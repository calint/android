java -server -cp bin htp.htp
