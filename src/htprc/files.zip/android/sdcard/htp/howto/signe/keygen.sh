keytool -genkey -alias applet.upload -validity 365
