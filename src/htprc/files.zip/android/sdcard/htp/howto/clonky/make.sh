gcc -o clonky *.c -lX11 -lXft -I/usr/include/freetype2/ -Wfatal-errors -Wall -Wextra&&
ls -l clonky
