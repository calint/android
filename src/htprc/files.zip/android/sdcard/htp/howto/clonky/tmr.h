#ifndef tmr_h
#define tmr_h
void tmr(const int intervall_s,void f(int));
#endif
