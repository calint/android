gcc serve.c htpc.c -o htp -Wfatal-errors -Wall -Wextra&
ls -l htp
