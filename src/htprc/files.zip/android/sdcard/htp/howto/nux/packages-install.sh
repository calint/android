sudo apt-get install htop sysv-rc-conf scrot feh leafpad xpad g++ libx11-dev


