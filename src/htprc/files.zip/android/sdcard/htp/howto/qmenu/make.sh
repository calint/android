rm qmenu
gcc -o qmenu qmenu.c -lX11 -Wall -Wextra -Wfatal-errors&&
ls -l qmenu
